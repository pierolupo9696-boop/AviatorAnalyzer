# Aviator Analyzer — Android

Progetto Android nativo, prima build, separato da SNAI.

Funzioni:
- inserimento dei moltiplicatori;
- salvataggio locale;
- statistiche generali;
- frequenze empiriche per soglia;
- analisi delle serie consecutive;
- storico degli ultimi 100 round visualizzati.

Per generare l'APK:
- importare il progetto in Android Studio;
- attendere la sincronizzazione Gradle;
- eseguire `Build > Build APK(s)`.

Nota: le statistiche sono descrittive dello storico inserito e non costituiscono una previsione del round successivo.
