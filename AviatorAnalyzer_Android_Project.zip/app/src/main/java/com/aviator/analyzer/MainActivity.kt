package com.aviator.analyzer

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.content.Context
import java.util.Locale
import kotlin.math.round

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("aviator", Context.MODE_PRIVATE) }
    private val rounds = mutableListOf<Double>()
    private lateinit var stats: LinearLayout
    private lateinit var history: LinearLayout
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
        render()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFF3F4F6.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "Aviator Analyzer\nAnalisi statistica dello storico"
            textSize = 24f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, Typeface.BOLD)
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFF111827.toInt())
        }
        content.addView(title)
        input = EditText(this).apply {
            hint = "Moltiplicatore, es. 1,42"
            inputType = 8194
        }
        val add = Button(this).apply { text = "AGGIUNGI ROUND"; setOnClickListener { addValues() } }
        val undo = Button(this).apply { text = "ANNULLA ULTIMO"; setOnClickListener { if(rounds.isNotEmpty()){rounds.removeAt(rounds.lastIndex);save();render()} } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; addView(input, LinearLayout.LayoutParams(0, -2, 1f)); addView(add) }
        content.addView(row)
        content.addView(undo)
        val note = TextView(this).apply {
            text = "I dati sono frequenze osservate nello storico inserito e non predicono il round successivo."
            textSize = 13f
            setPadding(4, 4, 4, 12)
        }
        content.addView(note)
        stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(stats)
        val seqTitle = TextView(this).apply { text = "Analisi sequenze"; textSize = 20f; setTypeface(null, Typeface.BOLD); setPadding(0,18,0,8) }
        content.addView(seqTitle)
        history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(history)
        val clear = Button(this).apply { text = "CANCELLA STORICO"; setOnClickListener { rounds.clear();save();render()} }
        content.addView(clear)
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun addValues() {
        val values = input.text.toString().replace(',', '.').split(Regex("[\\s;|]+"))
            .mapNotNull { it.toDoubleOrNull() }.filter { it >= 1.0 }
        rounds.addAll(values)
        input.text.clear()
        save(); render()
    }

    private fun save() { prefs.edit().putString("data", rounds.joinToString(",")).apply() }
    private fun load() {
        prefs.getString("data","")!!.split(",").mapNotNull { it.toDoubleOrNull() }.let { rounds.addAll(it) }
    }
    private fun f(x: Double) = String.format(Locale.US, "%.2f×", x)
    private fun pct(n: Int, d: Int) = if(d==0) "—" else String.format(Locale.US,"%.1f%%", n*100.0/d)

    private fun render() {
        stats.removeAllViews()
        val n=rounds.size
        val ordered=rounds.sorted()
        val avg=if(n>0) rounds.average() else Double.NaN
        val med=if(n==0) Double.NaN else if(n%2==1) ordered[n/2] else (ordered[n/2-1]+ordered[n/2])/2
        val lines = listOf(
            "Round analizzati: $n",
            "Media: ${if(n>0) f(avg) else "—"}",
            "Mediana: ${if(n>0) f(med) else "—"}",
            "Minimo: ${if(n>0) f(ordered.first()) else "—"}",
            "Massimo: ${if(n>0) f(ordered.last()) else "—"}",
            "% sotto 2×: ${pct(rounds.count{it<2},n)}"
        )
        lines.forEach { addStat(it) }
        listOf(1.2,1.5,2.0,3.0,5.0,10.0).forEach { t ->
            addStat("≥ ${t}×: ${pct(rounds.count{it>=t},n)}   |   < ${t}×: ${pct(rounds.count{it<t},n)}")
        }
        addStat("Serie consecutive sotto soglia:")
        for(t in listOf(1.5,2.0,3.0,5.0)) {
            var current=0; var max=0
            rounds.forEach { if(it<t){current++;max=maxOf(max,current)} else current=0 }
            addStat("  ${t}× → attuale ${current}, massima $max")
        }

        history.removeAllViews()
        if(n==0) addStatTo(history,"Nessun round inserito.")
        else rounds.asReversed().take(100).forEachIndexed { i,v -> addStatTo(history,"#${n-i}    ${f(v)}") }
    }
    private fun addStat(text:String) {
        addStatTo(stats,text)
    }
    private fun addStatTo(parent: LinearLayout,text:String) {
        parent.addView(TextView(this).apply {
            this.text=text; textSize=16f; setTextColor(0xFF111827.toInt()); setPadding(12,10,12,10)
            setBackgroundColor(0xFFFFFFFF.toInt())
        })
    }
}
